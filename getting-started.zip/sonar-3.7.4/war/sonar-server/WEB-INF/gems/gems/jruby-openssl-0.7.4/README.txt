= JRuby-OpenSSL

* http://jruby-extras.rubyforge.org/jruby-openssl

== DESCRIPTION:

JRuby-OpenSSL is an add-on gem for JRuby that emulates the Ruby OpenSSL native library.

Please report bugs and incompatibilities (preferably with testcases) to either the JRuby 
mailing list [1] or the JRuby bug tracker [2].

[1]: http://xircles.codehaus.org/projects/jruby/lists
[2]: http://jira.codehaus.org/browse/JRUBY
