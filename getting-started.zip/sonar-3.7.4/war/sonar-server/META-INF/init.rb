ENV['GEM_HOME'] ||= $servlet_context.getRealPath('/WEB-INF/gems')
